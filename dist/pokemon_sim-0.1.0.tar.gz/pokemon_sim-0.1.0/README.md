A terminal based pokemon battle simulator for now. I just wanted to test if I could do it terminal based. I'm planning to do it with a UI and maybe even web based.
I'm a young new programmer so please be kind with this code if it's messy, i'd also like feedbacks.
