from setuptools import setup, find_packages

setup(
    name='pokemon_sim',
    version='0.1.0',
    description='A turn-based Pokémon battle simulator in Python',
    author='Dreamsever',
    author_email='you@example.com',
    packages=find_packages(),
    install_requires=[],  # Add dependencies here if needed
)
